# time-is-a-flat-circle

<p align="center">
  <img width="100%" src="https://i.ytimg.com/vi/0mhZBLUyybo/maxresdefault.jpg" />
</p>

>simple endpoint to get data from harvest api without any trouble

used in combination with [this](https://github.com/tshamz/time-is-a-flat-circle).

a leaderboard for tracking total hours/billable hours from harvest.
